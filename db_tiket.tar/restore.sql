--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

DROP TABLE public.transaksi;
DROP TABLE public.tb_user;
DROP TABLE public.tb_order;
DROP TABLE public.tb_level;
DROP TABLE public.makanan;
DROP TABLE public.detail_order;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: detail_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE detail_order (
    id_detail_order character varying(12),
    id_order character varying(12),
    id_masakan character varying(12),
    ketarangan character varying(10),
    status_detail_order character varying(10)
);


ALTER TABLE detail_order OWNER TO postgres;

--
-- Name: makanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE makanan (
    id_makanan character varying(12),
    nama_masakan character varying(100),
    harga integer,
    status_masakan character varying(10)
);


ALTER TABLE makanan OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level character varying(12),
    nama_level character varying(100)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Name: tb_order; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_order (
    id_order character varying(12),
    no_meja character varying(12),
    tanggal date,
    id_user character varying(12),
    keterangan character varying(10),
    status_order character varying(10)
);


ALTER TABLE tb_order OWNER TO postgres;

--
-- Name: tb_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_user (
    id_user character varying(12),
    username character varying(100),
    password character varying(100),
    nama_user character varying(100),
    id_level character varying(12)
);


ALTER TABLE tb_user OWNER TO postgres;

--
-- Name: transaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE transaksi (
    id_transaksi character varying(12),
    id_user character varying(12),
    id_order character varying(12),
    tanggal date,
    total_bayar integer
);


ALTER TABLE transaksi OWNER TO postgres;

--
-- Data for Name: detail_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY detail_order (id_detail_order, id_order, id_masakan, ketarangan, status_detail_order) FROM stdin;
\.
COPY detail_order (id_detail_order, id_order, id_masakan, ketarangan, status_detail_order) FROM '$$PATH$$/2813.dat';

--
-- Data for Name: makanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY makanan (id_makanan, nama_masakan, harga, status_masakan) FROM stdin;
\.
COPY makanan (id_makanan, nama_masakan, harga, status_masakan) FROM '$$PATH$$/2814.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama_level) FROM stdin;
\.
COPY tb_level (id_level, nama_level) FROM '$$PATH$$/2812.dat';

--
-- Data for Name: tb_order; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_order (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM stdin;
\.
COPY tb_order (id_order, no_meja, tanggal, id_user, keterangan, status_order) FROM '$$PATH$$/2811.dat';

--
-- Data for Name: tb_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_user (id_user, username, password, nama_user, id_level) FROM stdin;
\.
COPY tb_user (id_user, username, password, nama_user, id_level) FROM '$$PATH$$/2810.dat';

--
-- Data for Name: transaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM stdin;
\.
COPY transaksi (id_transaksi, id_user, id_order, tanggal, total_bayar) FROM '$$PATH$$/2809.dat';

--
-- PostgreSQL database dump complete
--

